﻿namespace Crafting_Systems
{
    public class Person
    {
        private string name;

        public string Name
        { get => name;// read only
          set => name = value;//write only
                      
         }

        //list inventory- item

        public List<Item> Inventory= new List<Item>();





        public void Craft()
        {
            throw new System.NotImplementedException();
        }
    }
}