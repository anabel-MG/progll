﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crafting_Systems
{
    public class Engine
    {

        //player
        Person Player = new Person();
        Person Vendor = new Person();

        //system name

        private string name = "Potion crafting system";

        public void Setup() { }
    }

}
