﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Card_Games
{
    public class HighestMatchGame : Game
    {
        public override void Start()
        {
            Console.WriteLine("Starting Highest Match Game!");

            // Shuffle the deck
            Deck.Shuffle();

            // Deal cards to each player
            foreach (var player in Players)
            {
                player.AddCard(Deck.DrawCard());
                player.ShowHand();
            }

            // Implement the specific logic for Highest Match (comparing card suits and values)
        }
    }

}