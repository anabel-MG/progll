﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Card_Games
{
    public class SameOrDifferentGame : Game
    {
        public override void Start()
        {
            Console.WriteLine("Starting Same or Different Game!");

            // Shuffle the deck
            Deck.Shuffle();

            // Deal cards to the player
            foreach (var player in Players)
            {
                player.AddCard(Deck.DrawCard());
                player.ShowHand();
            }

            // Implement the logic for this specific game (comparing suits)
            // For example, you could display the current card and ask the player to guess if the next card is the same or different.
        }
    }

}
