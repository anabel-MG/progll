﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Card_Games
{
    public class Cards
    {// Properties for the suit and value of the card
        public string Suit { get; set; }
        public string Value { get; set; }

        // Constructor to initialize a card
        public Cards(string suit, string value)
        {
            Suit = suit;
            Value = value;
        }

        // Compare two cards (used for some game logic)
        public bool Compare(Cards otherCard)
        {
            return this.Suit == otherCard.Suit && this.Value == otherCard.Value;
        }
    }
}