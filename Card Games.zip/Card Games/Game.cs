﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Card_Games
{
    public abstract class Game
    {
        // List of players and the deck for the game
        protected List<Player> Players;
        protected Deck Deck;

        // Constructor to initialize the players and deck
        public Game()
        {
            Players = new List<Player>();
            Deck = new Deck();
        }

        // Abstract method for starting the game (to be implemented in derived classes)
        public abstract void Start();

        // End the game (common logic)
        public void End()
        {
            Console.WriteLine("Game Over!");
            // Logic for determining the winner can go here
        }

        // Add a player to the game
        public void AddPlayer(Player player)
        {
            Players.Add(player);
        }
    }
}