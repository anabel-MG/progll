﻿namespace Card_Games
{
     class Program
    {
        static void Main()
        {
            // Create a new game and add a player
            HigherOrLowerGame game = new HigherOrLowerGame();
            Player player = new Player();
            game.AddPlayer(player);

            // Start the game
            game.Start();

            // End the game
            game.End();
        }
    }
}
