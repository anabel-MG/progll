﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Formats.Asn1.AsnWriter;

namespace Card_Games
{
    using System;
    using System.Collections.Generic;

    public class Player
    {
        // Fields
        public int Score { get; private set; }
        public List<Cards> Hand { get; private set; }

        // Constructor
        public Player()
        {
            Score = 0;
            Hand = new List<Cards>();
        }

        // Method to add a card to the player's hand
        public void AddCard(Cards card)
        {
            Hand.Add(card);
        }

        // Method to show the player's hand
        public void ShowHand()
        {
            Console.WriteLine("Player's Hand:");
            foreach (var card in Hand)
            {
                Console.WriteLine(card.ToString()); // Assuming Card class has a ToString() override
            }
        }

        // Method to increase the player's score
        public void IncreaseScore()
        {
            Score++;
        }
    }

}
