﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Card_Games
{
    public class HigherOrLowerGame : Game
    {
        public override void Start()
        {
          

            // Shuffle the deck
            Deck.Shuffle();

            // Deal two cards to each player
            foreach (var player in Players)
            {
                player.AddCard(Deck.DrawCard());
                player.AddCard(Deck.DrawCard());
                player.ShowHand();
            }

            // Implement the specific logic for Higher or Lower (comparing card values)
        }
    }

}