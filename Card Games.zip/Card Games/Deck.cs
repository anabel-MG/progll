﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Card_Games
{
    public class Deck
    {
        // List to hold all the cards
        private List<Cards> cards;

        // Constructor to initialize and populate the deck
        public Deck()
        {
            cards = new List<Cards>();
            string[] suits = { "Hearts", "Diamonds", "Clubs", "Spades" };
            string[] values = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace" };

            // Populate the deck with all the cards
            foreach (var suit in suits)
            {
                foreach (var value in values)
                {
                    cards.Add(new Cards(suit, value));
                }
            }
        }

        // Shuffle the deck (randomizes the order of the cards)
        public void Shuffle()
        {
            Random rand = new Random();
            int n = cards.Count;
            while (n > 1)
            {
                n--;
                int k = rand.Next(n + 1);
                var card = cards[k];
                cards[k] = cards[n];
                cards[n] = card;
            }
        }

        // Draw a card from the deck (returns and removes the first card)
        public Cards DrawCard()
        {
            if (cards.Count > 0)
            {
                Cards cardToDraw = cards[0];
                cards.RemoveAt(0);
                return cardToDraw;
            }
            return null; // If the deck is empty
        }
    }
}