﻿namespace Crafting_Systems
{
    internal class Program
    {
        static void Main()
        {

            new Engine().Setup();

            //alternative option
            //Engine engine = new Engine();
            // engine.Setup();
        }
    }
}
