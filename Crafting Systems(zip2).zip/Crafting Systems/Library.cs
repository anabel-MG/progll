﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Crafting_Systems
{
  public class Library
{
    public static void Print(string message)
    {
        Console.WriteLine(message); // Print to console (we’ll extend this later for other platforms)
    }

    // Method to get user input
    public static string GetUserInput(string prompt)
    {
        Console.WriteLine(prompt);
        return Console.ReadLine(); // Get input from user
    }

    // Method to check if input is a valid number
    public static bool IsNumber(string input)
    {
        return double.TryParse(input, out double result); // Check if it's a number
    }
}
}
