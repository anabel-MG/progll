﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crafting_Systems
{
    public class Engine
    {
        // Players
        Person Player = new Person();
        Person Vendor = new Person();

        // Name of the system
        private string name = "Potion Crafting System";

        public void Setup()
        {
            Library.Print(name);
            Library.Print(Player.Information());

            // Sample list of recipes to test
            List<Recipe> recipes = new List<Recipe>
        {
            new Recipe("Chamomile Tea", 1, 7.00),
            new Recipe("Sleeping Potion", 2, 14.95)
        };

            // Call method to list recipes
            ListRecipes(recipes);
        }

        // Method to list all recipes
        public void ListRecipes(List<Recipe> recipes)
        {
            foreach (var recipe in recipes)
            {
                Console.WriteLine($"Recipe: {recipe.Name}, Makes: {recipe.Amount} cup(s), Value: ${recipe.Value}");
            }
        }

        // Method to show details of a selected recipe
        public void ShowRecipeDetails(Recipe recipe)
        {
            Console.WriteLine($"Recipe: {recipe.Name}");
            Console.WriteLine($"Makes: {recipe.Amount} amount");
            Console.WriteLine($"Value: {recipe.Value}");
            Console.WriteLine("Ingredients needed:");

            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"{ingredient.Key.Name}: {ingredient.Value} {ingredient.Key.Amount}");
            }
        }

    }
}

