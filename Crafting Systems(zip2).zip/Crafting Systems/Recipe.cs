﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Crafting_Systems
{
    public class Recipe
    {
        public string Name;     // The name of the recipe
        public double Amount;   // The amount the recipe produces (e.g., 1 cup)
        public double Value;    // The value (price) of the recipe

        // A dictionary to store ingredients and their amounts needed
        public Dictionary<Item, double> Ingredients = new Dictionary<Item, double>();

        public Recipe(string name, double amount, double value)
        {
            Name = name;
            Amount = amount;
            Value = value;
        }
    }
}