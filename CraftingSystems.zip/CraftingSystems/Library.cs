﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace CraftingSystems
{
    public class Library
    {




         public static string LoadTextFromExternalTextFile(string path)
          {
              if (path == "")
        {
        path = "../../../data/instructions.txt";

            }



                 
              string output = "";

              return output;

            
            if (!File.Exists(path)) {

                return null;
            
            }






          }



                public static void Pause()
        {
            Print("Press enter to continue...");
            GetInput();
            Console.Clear();
        }
        public static void Print(string message)
        {
            Console.WriteLine(message);
        }

        public static void Print()
        {
            Print("");
        }

        public static string GetInput()
        {
            return Console.ReadLine();
        }

        public static int ConvertStringToInteger(string s)
        {
            if (int.TryParse(s, out int result))
            {
                return result;
            }

            return 0;
        }
        public static float ConvertStringToFloat(string s)
        {
            if (float.TryParse(s, out float result))
            {
                return result;
            }

            return 0;
        }
        public static double ConvertStringToDouble(string s)
        {
            if (double.TryParse(s, out double result))
            {
                return result;
            }

            return 0;
        }







        public List<Recipe> LoadRecipes(string fileName)
        {

            if (fileName == "")
            {
                fileName = "../../../data/recipes.xml";

            }

            if (!File.Exists(fileName)) {

                return null;
            
            }


            List<Recipe> Recipes = new List<Recipe>();
            XmlDocument doc = new XmlDocument();
            doc.Load(fileName);
            XmlNode root = doc.DocumentElement;
            XmlNodeList recipeList = root.SelectNodes("/recipes/recipe");
            XmlNodeList ingredientsList;

            foreach (XmlElement recipe in recipeList)
            {
                Recipe recipeToAdd = new Recipe();
                recipeToAdd.Name = recipe.GetAttribute("title");
                recipeToAdd.Description = recipe.GetAttribute("description");
                string yieldAmount = recipe.GetAttribute("yieldAmount");
                if (float.TryParse(yieldAmount, out float amount))
                { recipeToAdd.YieldAmount = amount; }

                recipeToAdd.YieldType = recipe.GetAttribute("yieldType");
                string recipevalue = recipe.GetAttribute("value");
                if (float.TryParse(recipevalue, out float value))
                { recipeToAdd.Value = value; }

                ingredientsList = recipe.ChildNodes; //for ingredients

                foreach (XmlElement i in ingredientsList)
                {
                    string ingredientName = i.GetAttribute("itemName");
                    string ingredientAmountString = i.GetAttribute("amount");
                    float ingredientAmount = 0;
                    if (float.TryParse(ingredientAmountString, out float e))
                    { ingredientAmount = e; }
                    string ingredientAmountType = i.GetAttribute("amountType");
                    string tempIngredientValue = i.GetAttribute("value");
                    float ingredientValue = 0;
                    if (float.TryParse(tempIngredientValue, out float ingValue))
                    { ingredientValue = ingValue; }

                    recipeToAdd.Ingredients.Add(new Item(ingredientName, ingredientAmount, ingredientAmountType, ingredientValue));
                }
                Recipes.Add(recipeToAdd);
            }
            return Recipes;
        }








    }
}
