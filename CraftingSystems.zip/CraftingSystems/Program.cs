﻿namespace CraftingSystems
{
    internal class Program

    {
        static void Main()

        {

            Console.Title = "Potion Making ";


            new Engine().Setup();

            //alternative option
            //Engine engine = new Engine();
            // engine.Setup();

        }

    }
}
