﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CraftingSystems
{
    public class Item
    {
        public string Name;
        public string Description;
        public float Value;
        public float Amount = 1f;
        public string AmountType = "cup(s)";


        public Item(string ingredientName, float ingredientAmount, string ingredientAmountType, float ingredientValue)
        {
            Name = ingredientName;
            Amount = ingredientAmount;
            Value = ingredientValue;
            AmountType = ingredientAmountType;

        }

        public Item()
        {

        }

    }
}
